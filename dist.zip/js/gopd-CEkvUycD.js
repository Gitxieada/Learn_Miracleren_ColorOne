import{g as t}from"./get-intrinsic-BKEvijrG.js";var e=t,r=e("%Object.getOwnPropertyDescriptor%",!0);if(r)try{r([],"length")}catch{r=null}var n=r;export{n as g};
